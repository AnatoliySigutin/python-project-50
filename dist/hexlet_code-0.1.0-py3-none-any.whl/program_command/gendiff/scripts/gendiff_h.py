from program_command.gendiff.main import gendiff_h

def main():
	gendiff_h()



if __name__ == "__main__":
    main()