import argparse


def gendiff_h():
    parser = argparse.ArgumentParser(
        description="Comparing two configuration files and showing differences."
    )

    parser.add_argument("first_file", help="First file to compare")
    parser.add_argument("second_file", help="Second file to compare")
    parser.add_argument(
        "-f",
        "--format",
        metavar="FORMAT",
        default="stylish",
        choices=["stylish", "plain", "json"],
        help="set format of output (default: stylish)",
    )

    args = parser.parse_args()

    print(
        f"Processing comparison between '{args.first_file}' "
        f"and '{args.second_file}'."
        f" Selected format: {args.format}"
    )
