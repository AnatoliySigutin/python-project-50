### Hexlet tests and linter status:
[![Actions Status](https://github.com/AnatoliySigutin/python-project-50/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/AnatoliySigutin/python-project-50/actions)
asciinema: https://asciinema.org/a/v6GKoI3Qytw34ZTfx8mUtGIfD
